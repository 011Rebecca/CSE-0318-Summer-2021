
 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">


  

<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/hover.css/2.3.0/css/hover-min.css">
<link rel="stylesheet" type="text/css" href="css/style.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">


<section id="section-one">
  <div class="login-modal">
    <div class="close-btn">
      <a href="#">&times;</a>
    </div>
    <h1>Login</h1>
    <form method="POST" action="/api/user/login">
      <input type="text" name="email" placeholder="Your email" required>
      <input type="password" name="password" placeholder="Your password" required>
    </form>
    <a href="#" class="forgot-password">Forgot password ?</a>
    <input type="submit" name="login" value="Login">
    
    
    
    <span class="login-modal-text">or Login in with</span>
    
    <div class="login-with">
      <button type="button" class="login-with-btn"><i class="fa fa-facebook"></i></button>
      <button type="button" class="login-with-btn"><i class="fa fa-twitter"></i></button>
      <button type="button" class="login-with-btn"><i class="fa fa-google"></i></button>
      <div class="login-modal-footer">
        <span>Not a member ? <a href="#">Sign up</a></span>
      </div>
    </div>
    
  </div>
</section>

<section id="section-two">
  <div class="login-modal">
    <div class="close-btn">
      <a href="#">&times;</a>
    </div>
    <h1>Sing up</h1>
    <form action="/api/user/register" method="POST">
      <!-- First Name -->
      <input type="text" name="first_name" class="username-input" placeholder="Firstname" required>
      <!-- Last Name -->
      <input type="text" name="last_name" class="lastname-input" placeholder="Lastname" required>
      <!-- Email -->
      <input type="email" name="email" class="email-input" placeholder="Email" required>
      <!-- Password -->
      <input type="password" name="password" class="password-input" placeholder="Password" required>
      <!-- Confirm Password -->
      <input type="password" name="password2" class="password-input" placeholder="Confirm password" required>
    </form>
    <a href="#" class="sign-up">Sing up</a>
    <input type="checkbox" name="checkbox" value="check" id="agree" !> 
    <p>I have read and agree to the Terms and Conditions and Privacy Policy</p>
  </div>
</section>

