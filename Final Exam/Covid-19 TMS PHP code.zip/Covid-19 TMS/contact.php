<?php

if(isset($_POST ['btn-send']))

{
    echo 'working';
}
?>