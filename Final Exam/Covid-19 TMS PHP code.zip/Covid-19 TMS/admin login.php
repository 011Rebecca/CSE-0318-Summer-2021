<?php
  require("connection.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>admin login panel</title>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1 shrink-to-fit=no" >
  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/style.css">
  
</head>
<body>
    <div class="jumbotron" style="background:url('image/4.png') no-repeat; background-size:cover;  height: 700px;">

    <div class="admin">
    <div class="login-form" >
    <h3>Admin Login</h3>

    <form method="POST">

      <div class="input-field">
        <i class="fas fa-user"></i>
         <input type="text" placeholder="Admin Name" name="AdminName">
      </div>

      <div class="input-field">
        <i class="fas fa-lock"></i>
        
        <input type="text" placeholder="Password" name="AdminPassword">
      </div>

      <button type="submit">Sign In</button>

      <div class="extra">
        <a href="#">Forgot Password ?</a>
      </div>

    </form>
    </div>
    </div>
    </div>

<?php


?>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>


    
</body>
</html>