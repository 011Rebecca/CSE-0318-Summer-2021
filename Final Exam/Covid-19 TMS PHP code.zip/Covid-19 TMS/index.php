<!DOCTYPE html>
<html>
<head>
    <title>Covid19 TMS</title>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="css/style.css">
  
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Covid-19 TMS</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav ml-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="index.php">ABOUT</a>
        </li>
        
        <li class="nav-item">
          <a class="nav-link" href="admin login.php">ADMIN</a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="user login.php">USER LOGIN</a>
        </li>  

        <li class="nav-item">
        <button type="button" class="btn btn-light">CONTACT</button>
        </li> 

      </ul>


    </div>
  </div>
</nav>



<div id="demo" class="carousel slide" data-ride="carousel">
  <ul class="carousel-indicators">
    <li data-target="#demo" data-slide-to="0" class="active"></li>
    <li data-target="#demo" data-slide-to="1"></li>
    <li data-target="#demo" data-slide-to="2"></li>
  </ul>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="image/COVID 19.jpg" alt="" width="1536" height="600" >
      <div class="carousel-caption">
        <h3></h3>
        <p>COVID-19 is an infectious disease caused by a newly discovered coronavirus. Most people infected with the COVID-19, virus will experience mild to moderate, respiratory illness & recover without requiring special treatment. Older people and those with underlying medical problem like cardiovascular disease.</p>
      </div>   
    </div>
    <div class="carousel-item">
      <img src="image/Symptoms2.png" alt="" width="1536" height="600" >
      <div class="carousel-caption">
        <h3>Symptoms</h3>
        <p></p>
      </div>   
    </div>
    <div class="carousel-item">
      <img src="image/Health1.png" alt="" width="1536" height="600" >
      <div class="carousel-caption">
        <h3></h3>
        <p></p>
      </div>   
    </div>
  </div>
  <a class="carousel-control-prev" href="#demo" data-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </a>
  <a class="carousel-control-next" href="#demo" data-slide="next">
    <span class="carousel-control-next-icon"></span>
  </a>
</div>





<div class="container">
  <div style="text-align:center">
    <h2>Contact Us</h2>
    <p>Leave us a message:</p>
  </div>
  <div class="row">
    <div class="column">
      <img src="image/contact part.png" style="width:100%" height="75%">
    </div>
    <div class="column">
      <form action="contact.php" method="POST">
        <label for="fname">Name:</label>
        <input type="text" id="fname" name="firstname" placeholder="Your name..">
        <label for="lname">Contact:</label>
        <input type="text" id="lname" name="lastname" placeholder="Your contact..">
        <label for="email">Email:</label>
        <input type="text" id="lname" name="lastname" placeholder="Your email..">
        
        <label for="subject">Subject</label>
        <textarea id="subject" name="subject" placeholder="Write something.." style="height:170px"></textarea>
         <button type="button" class="btn btn-success" name="btn-send">Send</button>
      </form>
    </div>
  </div>
</div>


  <footer>
    <div class="wrapper">
      <small>&copy;2017 <strong>Awesome Company</strong>, All Rights Reserved</small>
      <nav class="footer-nav">
        <a href="#">Back to Top</a>
        <a href="#">Terms of Use</a>
        <a href="#">Privacy</a>
      </nav>
    </div>
  </footer>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>


    
</body>
</html>
